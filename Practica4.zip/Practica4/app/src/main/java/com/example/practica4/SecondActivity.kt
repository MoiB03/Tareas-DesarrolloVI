package com.example.practica4

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.example.practica2.R
import com.opencsv.CSVWriter
import org.apache.poi.ss.usermodel.WorkbookFactory
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStreamWriter

class SecondActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, Fragment_Resultados())
            .commit()

        val toolbar: Toolbar = findViewById(R.id.toolbar2)
        setSupportActionBar(toolbar)

        val resultado = intent.getDoubleExtra("RESULTADO", 0.0)
        val conversion = intent.getStringExtra("CONVERSION")

        val dbHelper = DatabaseHelper(this)
        if (conversion != null) {
            dbHelper.addConversionResult(resultado, conversion)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_toolbar, menu)
        return true
    }

    private fun exportToCSV(data: List<List<String>>, filePath: String) {
        val outputFile = File(filePath)
        val writer = CSVWriter(OutputStreamWriter(FileOutputStream(outputFile), "UTF-8"))

        // Escribir los datos al archivo CSV
        for (rowData in data) {
            writer.writeNext(rowData.toTypedArray())
        }

        writer.close()
    }

    private fun exportToExcel(data: List<List<String>>, filePath: String, isXlsx: Boolean) {
        val workbook = if (isXlsx) XSSFWorkbook() else WorkbookFactory.create(true)

        // Crear una nueva hoja en el libro de trabajo
        val sheet = workbook.createSheet("Datos")

        // Escribir los datos en la hoja
        var rowNum = 0
        for (rowData in data) {
            val row = sheet.createRow(rowNum++)
            var cellNum = 0
            for (cellData in rowData) {
                row.createCell(cellNum++).setCellValue(cellData)
            }
        }

        // Escribir el libro de trabajo en un archivo
        val fileOut = FileOutputStream(filePath)
        workbook.write(fileOut)
        fileOut.close()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val dbHelper = DatabaseHelper(this) // Asegúrate de tener acceso al contexto aquí

        return when (item.itemId) {
            R.id.csv -> {
                val data: List<List<String>> = dbHelper.getAllResults().map { listOf(it.first, it.third.toString()) }
                exportToCSV(data, "/sdcard/archivo.csv")
                true
            }
            R.id.xls -> {
                val data: List<List<String>> = dbHelper.getAllResults().map { listOf(it.first, it.third.toString()) }
                exportToExcel(data, "/sdcard/archivo.xls", false)
                true
            }
            R.id.xlsx -> {
                val data: List<List<String>> = dbHelper.getAllResults().map { listOf(it.first, it.third.toString()) }
                exportToExcel(data, "/sdcard/archivo.xlsx", true)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }



}
